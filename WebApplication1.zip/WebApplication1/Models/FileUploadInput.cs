﻿namespace WebApplication1.Models
{
    public class FileUploadInput
    {
        public IFormFile? file { get; set; }
        public string? id { get; set; }
        public string? name { get; set; }
        public string? email { get; set; }
        public string? fileContentType { get; set; }
        public string? fileName { get; set; }
    }
}
