﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
       
        [HttpPost]
        public ActionResult Post([FromForm] FileUploadInput inputData)
        {
            IFormFile? file = inputData.file;

            if (file != null)
            {
                long length = file.Length;
                if (length < 0)
                    return BadRequest();

                using var fileStream = file.OpenReadStream();
                byte[] bytes = new byte[length];
                fileStream.Read(bytes, 0, (int)file.Length);

                string base64String = Convert.ToBase64String(bytes);

            }
            

            return Ok();
        }

         
    }
}
